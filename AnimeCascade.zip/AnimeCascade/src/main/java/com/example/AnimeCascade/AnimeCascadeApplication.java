package com.example.AnimeCascade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimeCascadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimeCascadeApplication.class, args);
	}

}
