package com.example.manytomany.model;

import lombok.Data;

@Data
public class DepartmentResponse {
    private  Long id;
}
