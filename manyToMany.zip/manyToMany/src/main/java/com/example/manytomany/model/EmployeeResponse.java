package com.example.manytomany.model;

import lombok.Data;

@Data
public class EmployeeResponse {
    private  Long id;
}
