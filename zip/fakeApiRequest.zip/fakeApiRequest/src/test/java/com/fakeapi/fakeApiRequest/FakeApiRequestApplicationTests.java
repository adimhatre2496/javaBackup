package com.fakeapi.fakeApiRequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakeApiRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
