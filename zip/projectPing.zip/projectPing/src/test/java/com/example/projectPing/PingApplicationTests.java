package com.example.projectPing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PingApplicationTests {

	@Test
	void contextLoads() {
	}

}
