package com.example.PersonDev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonDevApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonDevApplication.class, args);
	}

}
