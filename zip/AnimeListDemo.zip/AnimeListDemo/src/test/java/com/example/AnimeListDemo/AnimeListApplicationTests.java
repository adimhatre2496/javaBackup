package com.example.AnimeListDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimeListApplicationTests {

	@Test
	void contextLoads() {
	}

}
