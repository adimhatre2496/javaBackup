package com.example.SpringCollege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClgStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
