package com.fakeapi.fakeApiRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FakeApiRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FakeApiRequestApplication.class, args);
	}

}
