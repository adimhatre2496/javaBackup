package com.example.manytomanysecond;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytomanysecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
