package com.example.manytomanysecond;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytomanysecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManytomanysecondApplication.class, args);
	}

}
