package com.example.manytomanysecond.model;

public class EmployeeDepartment {

}
