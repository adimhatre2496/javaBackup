package com.example.Cascade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CascadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
