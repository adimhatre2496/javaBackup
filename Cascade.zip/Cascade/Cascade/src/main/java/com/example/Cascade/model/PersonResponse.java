package com.example.Cascade.model;

import lombok.Data;

@Data
public class PersonResponse {
    Long id;
}
